#!/usr/bin/env python3
"""MetricOS Control Center. Persists profiles and applies a small, safe native KDE mapping."""
from __future__ import annotations
import json, os, re, shutil, subprocess, sys, tempfile
from pathlib import Path
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QColor, QFont
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QFrame, QHBoxLayout, QVBoxLayout,
    QLabel, QPushButton, QListWidget, QListWidgetItem, QStackedWidget, QScrollArea, QLineEdit,
    QCheckBox, QSlider, QComboBox, QColorDialog, QMessageBox, QSizePolicy)

DATA = Path('/usr/share/metricos/settings-catalog.json')
CFG = Path.home()/'.config'/'metricos'/'settings.json'

STYLE = r"""
QWidget { background:#070910; color:#edf0fa; font-family:'Noto Sans','Inter',sans-serif; font-size:13px; }
QFrame#sidebar { background:#090c15; border-right:1px solid #24283a; }
QFrame#header { background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 #17142a,stop:1 #0c1725); border:1px solid #342b59; border-radius:18px; }
QFrame#card { background:rgba(20,23,37,238); border:1px solid #282d43; border-radius:14px; }
QFrame#card:hover { border:1px solid #7560bd; }
QLabel#brand { font-size:24px; font-weight:800; letter-spacing:2px; color:#f6f5ff; }
QLabel#muted { color:#969db6; }
QLabel#section { font-size:18px; font-weight:700; color:#dcd9ff; padding:8px 2px; }
QPushButton { background:#171a2a; border:1px solid #343a55; border-radius:10px; padding:9px 14px; color:#eff0ff; }
QPushButton:hover { background:#25203f; border-color:#9375f2; }
QPushButton#primary { background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 #7956dc,stop:1 #247eaa); border:0; font-weight:700; }
QPushButton#primary:hover { background:#8d71ef; }
QListWidget { background:transparent; border:0; outline:0; }
QListWidget::item { padding:10px 12px; border-radius:9px; color:#aeb4ca; margin:2px 4px; }
QListWidget::item:selected { background:#282143; color:#fff; border:1px solid #4b3c78; }
QLineEdit, QComboBox { background:#101421; border:1px solid #30364d; border-radius:9px; padding:8px 10px; color:#f0f2ff; }
QComboBox QAbstractItemView { background:#101421; color:#f0f2ff; selection-background-color:#59449a; }
QCheckBox { spacing:8px; color:#eff0fb; }
QCheckBox::indicator { width:18px; height:18px; border-radius:6px; border:1px solid #555e7c; background:#0e1220; }
QCheckBox::indicator:checked { background:#8b67ee; border:1px solid #b7a0ff; }
QSlider::groove:horizontal { background:#252a3d; height:6px; border-radius:3px; }
QSlider::handle:horizontal { background:#a38aff; width:16px; margin:-6px 0; border-radius:8px; }
QScrollArea { border:0; background:transparent; }
"""

def defaults(catalog):
    return {group: {x['id']: x['default'] for x in catalog[group]} for group in ('settings','appearance')}

def load_state(catalog):
    state=defaults(catalog)
    try:
        data=json.loads(CFG.read_text(encoding='utf-8'))
        for group in state:
            if isinstance(data.get(group),dict):
                for key,val in data[group].items():
                    if key in state[group]: state[group][key]=val
    except (OSError, ValueError, TypeError): pass
    return state

def write_state(state):
    CFG.parent.mkdir(parents=True,exist_ok=True)
    fd,tmp=tempfile.mkstemp(prefix='settings.',suffix='.json',dir=CFG.parent)
    try:
        with os.fdopen(fd,'w',encoding='utf-8') as f:
            json.dump(state,f,indent=2,ensure_ascii=False); f.write('\n')
        os.chmod(tmp,0o600); os.replace(tmp,CFG)
    finally:
        if os.path.exists(tmp): os.unlink(tmp)

def run(argv, timeout=5):
    try: return subprocess.run(argv, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=timeout, check=False).returncode==0
    except (OSError, subprocess.TimeoutExpired): return False

def kwrite(file, groups, key, value):
    exe=shutil.which('kwriteconfig6')
    if not exe: return False
    args=[exe,'--file',str(Path.home()/'.config'/file)]
    for g in groups: args += ['--group',str(g)]
    args += ['--key',str(key),str(value)]
    return run(args)

def find_panel_id():
    p=Path.home()/'.config'/'plasma-org.kde.plasma.desktop-appletsrc'
    try: txt=p.read_text(encoding='utf-8',errors='replace')
    except OSError: return '2'
    matches=list(re.finditer(r'^\[Containments\]\[(\d+)\]\s*$',txt,re.M))
    for i,m in enumerate(matches):
        end=matches[i+1].start() if i+1<len(matches) else len(txt)
        if 'plugin=org.kde.panel' in txt[m.start():end]: return m.group(1)
    return '2'

def apply_native(state):
    messages=[]
    s=state['settings']; a=state['appearance']
    profile=s.get('power.power_profile', s.get('performance.profile','balanced'))
    if profile in ('balanced','performance','power-saver') and shutil.which('powerprofilesctl'):
        messages.append('Power profile applied' if run(['powerprofilesctl','set',profile]) else 'Power profile could not be applied')
    # KDE compositor settings are user-level; no root actions are performed.
    speed=int(s.get('performance.animation_speed',3))
    if kwrite('kwinrc',['Compositing'],'AnimationSpeed',speed): messages.append('KWin animation speed saved')
    blur=bool(s.get('performance.blur',True))
    if kwrite('kwinrc',['Plugins'],'blurEnabled','true' if blur else 'false'): messages.append('KWin blur setting saved')
    scheme='MetricOS-Carbon' if a.get('oled.accent_color')=='cyan' else 'MetricOS-OLED'
    if shutil.which('plasma-apply-colorscheme'):
        if run(['plasma-apply-colorscheme',scheme]): messages.append('KDE color scheme applied')
    # Update real existing Plasma panel settings when a panel is present.
    panel=find_panel_id()
    floating='1' if s.get('taskbar.floating',True) else '0'
    thickness=int(a.get('panel.panel_height',s.get('taskbar.height',48)))
    opacity={'opaque':0,'translucent':1,'adaptive':2}.get(s.get('taskbar.opacity','adaptive'),2)
    visibility={'always':0,'auto-hide':1,'dodge-windows':2}.get(s.get('taskbar.visibility','always'),0)
    ok1=kwrite('plasmashellrc',['PlasmaViews',f'Panel {panel}'],'floating',floating)
    ok2=kwrite('plasmashellrc',['PlasmaViews',f'Panel {panel}','Defaults'],'thickness',thickness)
    ok3=kwrite('plasmashellrc',['PlasmaViews',f'Panel {panel}'],'panelOpacity',opacity)
    ok4=kwrite('plasmashellrc',['PlasmaViews',f'Panel {panel}'],'panelVisibility',visibility)
    if any((ok1,ok2,ok3,ok4)): messages.append('Plasma taskbar preferences saved (log out/in to refresh panel)')
    if s.get('gaming.mangohud',False):
        (CFG.parent/'game-env.sh').write_text('export MANGOHUD=1\n',encoding='utf-8')
    else:
        try: (CFG.parent/'game-env.sh').unlink()
        except FileNotFoundError: pass
    return messages

class Window(QMainWindow):
    def __init__(self):
        super().__init__()
        try: self.catalog=json.loads(DATA.read_text(encoding='utf-8'))
        except Exception as e:
            QMessageBox.critical(None,'MetricOS settings unavailable',str(e)); raise
        self.state=load_state(self.catalog); self.setWindowTitle('MetricOS Control Center'); self.resize(1180,820); self.setMinimumSize(900,650)
        base=QWidget(); outer=QHBoxLayout(base); outer.setContentsMargins(0,0,0,0); outer.setSpacing(0)
        side=QFrame(); side.setObjectName('sidebar'); side.setFixedWidth(244); sl=QVBoxLayout(side); sl.setContentsMargins(16,22,14,18)
        brand=QLabel('METRICOS'); brand.setObjectName('brand'); sl.addWidget(brand)
        tagline=QLabel('PERFORMANCE, UNDER YOUR CONTROL'); tagline.setObjectName('muted'); tagline.setWordWrap(True); sl.addWidget(tagline); sl.addSpacing(20)
        self.nav=QListWidget(); self.nav.setSpacing(2); sl.addWidget(self.nav,1)
        self.nav_items=[]
        labels=[('Overview','overview')]+[(x.replace('_',' ').title(),x) for x in self.catalog['settings_categories']]+[('Liquid Glass','appearance')]
        # Merge all appearance controls into a single searchable page with subgroups.
        for label,key in labels:
            it=QListWidgetItem(label); it.setData(Qt.ItemDataRole.UserRole,key); self.nav.addItem(it)
        self.nav.currentRowChanged.connect(self.change_page)
        right=QWidget(); rl=QVBoxLayout(right); rl.setContentsMargins(24,20,24,18); rl.setSpacing(14)
        header=QFrame(); header.setObjectName('header'); hl=QVBoxLayout(header); hl.setContentsMargins(22,18,22,18)
        self.page_title=QLabel('Welcome to MetricOS'); self.page_title.setStyleSheet('font-size:22px;font-weight:800;color:#f3f1ff;'); hl.addWidget(self.page_title)
        self.page_sub=QLabel('Tune your gaming desktop, OLED palette and system preferences.'); self.page_sub.setObjectName('muted'); hl.addWidget(self.page_sub)
        rl.addWidget(header)
        top=QHBoxLayout(); self.search=QLineEdit(); self.search.setPlaceholderText('Search settings in this section…'); self.search.textChanged.connect(self.filter_page); top.addWidget(self.search,1)
        self.count=QLabel('130 settings · 60 appearance controls'); self.count.setObjectName('muted'); top.addWidget(self.count); rl.addLayout(top)
        self.stack=QStackedWidget(); self.scroll=QScrollArea(); self.scroll.setWidgetResizable(True); self.body=QWidget(); self.body_layout=QVBoxLayout(self.body); self.body_layout.setContentsMargins(2,2,2,8); self.body_layout.setSpacing(10); self.scroll.setWidget(self.body); self.stack.addWidget(self.scroll); rl.addWidget(self.stack,1)
        bottom=QHBoxLayout(); self.status=QLabel('Changes are saved to your user profile when you click Apply.'); self.status.setObjectName('muted'); bottom.addWidget(self.status,1)
        reset=QPushButton('Reset section'); reset.clicked.connect(self.reset_page); bottom.addWidget(reset)
        apply=QPushButton('Save & Apply'); apply.setObjectName('primary'); apply.clicked.connect(self.apply); bottom.addWidget(apply); rl.addLayout(bottom)
        outer.addWidget(side); outer.addWidget(right,1); self.setCentralWidget(base)
        self.current='overview'; self.nav.setCurrentRow(0)

    def clear_body(self):
        while self.body_layout.count():
            it=self.body_layout.takeAt(0); w=it.widget()
            if w: w.deleteLater()

    def change_page(self,row):
        if row<0: return
        key=self.nav.item(row).data(Qt.ItemDataRole.UserRole); self.current=key
        self.clear_body(); self.search.clear()
        if key=='overview':
            self.page_title.setText('Welcome to MetricOS')
            self.page_sub.setText('A lean KDE gaming desktop with 130 system preferences and 60 Liquid Glass controls.')
            for title,desc in [('Gaming-first base','GameMode, MangoHud, Lutris and Vulkan tools are included.'),('Two browser choices','Firefox ESR plus Google Chrome Stable from Google’s signed repository.'),('OLED visual system','MetricOS OLED colors, deep-black wallpaper, floating translucent KDE panel.'),('Keep control local','Your preferences are stored in ~/.config/metricos/settings.json. No MetricOS telemetry is enabled.')]:
                self.add_info(title,desc)
            self.add_info('Build status','This app is installed in the live image. The ISO must be built on a network-connected Debian/Ubuntu build machine.')
            self.count.setText('130 settings · 60 appearance controls')
            return
        if key=='appearance':
            self.page_title.setText('Liquid Glass & OLED')
            self.page_sub.setText('60 visual preferences grouped into glass, palette, gradients, panel, windows and motion.')
            data=self.catalog['appearance']
        else:
            self.page_title.setText(key.replace('_',' ').title())
            self.page_sub.setText('MetricOS settings · changes apply only where the control has a documented native mapping.')
            data=[x for x in self.catalog['settings'] if x['category']==key]
        self.count.setText(f'{len(data)} controls')
        categories=[]
        for item in data:
            if item['category'] not in categories: categories.append(item['category'])
        for cat in categories:
            h=QLabel(cat.replace('_',' ').title()); h.setObjectName('section'); self.body_layout.addWidget(h)
            for item in [x for x in data if x['category']==cat]: self.add_setting(item, 'appearance' if key=='appearance' else 'settings')
        self.body_layout.addStretch(1)

    def add_info(self,title,desc):
        card=QFrame(); card.setObjectName('card'); l=QVBoxLayout(card); l.setContentsMargins(18,14,18,14)
        t=QLabel(title); t.setStyleSheet('font-size:15px;font-weight:700;color:#e5ddff'); d=QLabel(desc); d.setObjectName('muted'); d.setWordWrap(True); l.addWidget(t); l.addWidget(d); self.body_layout.addWidget(card)

    def add_setting(self,item,group):
        card=QFrame(); card.setObjectName('card'); card.setProperty('searchText',(item['title']+' '+item['description']).lower())
        row=QHBoxLayout(card); row.setContentsMargins(16,10,16,10); left=QVBoxLayout(); left.setSpacing(3)
        title=QLabel(item['title']); title.setStyleSheet('font-weight:650;color:#edf0fb')
        desc=QLabel(item['description']); desc.setObjectName('muted'); desc.setWordWrap(True); desc.setMaximumWidth(660)
        left.addWidget(title); left.addWidget(desc); row.addLayout(left,1)
        key=item['id']; val=self.state[group].get(key,item['default']); typ=item['type']
        if typ=='toggle':
            w=QCheckBox(); w.setChecked(bool(val)); w.toggled.connect(lambda v,k=key,g=group:self.set_val(g,k,v)); row.addWidget(w)
        elif typ=='range':
            wrap=QVBoxLayout(); value=QLabel(str(val)); value.setAlignment(Qt.AlignmentFlag.AlignRight)
            slider=QSlider(Qt.Orientation.Horizontal); slider.setMinimum(item['min']); slider.setMaximum(item['max']); slider.setSingleStep(item.get('step',1)); slider.setValue(int(val)); slider.setFixedWidth(190)
            slider.valueChanged.connect(lambda v,k=key,g=group,l=value:self.slider_val(g,k,v,l)); wrap.addWidget(value); wrap.addWidget(slider); row.addLayout(wrap)
        elif typ=='choice':
            w=QComboBox(); w.addItems(item['choices']); w.setCurrentText(str(val)); w.currentTextChanged.connect(lambda v,k=key,g=group:self.set_val(g,k,v)); w.setMinimumWidth(150); row.addWidget(w)
        self.body_layout.addWidget(card)

    def set_val(self,g,k,v): self.state[g][k]=v
    def slider_val(self,g,k,v,label): self.state[g][k]=v; label.setText(str(v))
    def filter_page(self,text):
        q=text.strip().lower()
        for i in range(self.body_layout.count()):
            w=self.body_layout.itemAt(i).widget()
            if w and w.objectName()=='card': w.setVisible(not q or q in w.property('searchText'))
            elif w and w.objectName()=='section': w.setVisible(not q or q in w.text().lower())

    def reset_page(self):
        key=self.current
        if key=='overview': return
        group='appearance' if key=='appearance' else 'settings'
        cat=None if key=='appearance' else key
        for item in self.catalog[group]:
            if cat is None or item['category']==cat: self.state[group][item['id']]=item['default']
        self.change_page(self.nav.currentRow()); self.status.setText('Defaults restored for this section. Click Save & Apply to keep them.')

    def apply(self):
        try: write_state(self.state)
        except OSError as e:
            QMessageBox.critical(self,'Could not save settings',str(e)); return
        msgs=apply_native(self.state)
        summary='Settings saved to your MetricOS profile.'
        if msgs: summary+=' Native changes: '+'; '.join(msgs)+'.'
        summary+=' Other preferences remain stored in the profile and do not silently change kernel or security settings.'
        self.status.setText(summary)


def main():
    app=QApplication(sys.argv); app.setStyle('Fusion'); app.setStyleSheet(STYLE)
    win=Window(); win.show(); sys.exit(app.exec())
if __name__=='__main__': main()
