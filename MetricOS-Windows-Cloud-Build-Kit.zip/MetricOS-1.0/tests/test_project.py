import json
import pathlib
import re
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
INCLUDES = ROOT / "config/includes.chroot"


class MetricOSProjectTests(unittest.TestCase):
    def setUp(self):
        self.catalog = json.loads((INCLUDES / "usr/share/metricos/settings-catalog.json").read_text())

    def test_catalog_counts_and_unique_ids(self):
        self.assertEqual(len(self.catalog["settings"]), 130)
        self.assertEqual(len(self.catalog["appearance"]), 60)
        ids = [item["id"] for group in ("settings", "appearance") for item in self.catalog[group]]
        self.assertEqual(len(ids), len(set(ids)))

    def test_catalog_categories_are_complete(self):
        used = {item["category"] for item in self.catalog["settings"]}
        self.assertEqual(used, set(self.catalog["settings_categories"]))
        self.assertEqual(len(self.catalog["settings_categories"]), 13)

    def test_catalog_defaults_are_in_range(self):
        for group in ("settings", "appearance"):
            for item in self.catalog[group]:
                self.assertIn("default", item, item["id"])
                self.assertIn(item["type"], {"toggle", "range", "choice"}, item["id"])
                if item["type"] == "choice":
                    self.assertIn(item["default"], item["choices"], item["id"])
                if item["type"] == "range":
                    self.assertLessEqual(item["min"], item["default"], item["id"])
                    self.assertLessEqual(item["default"], item["max"], item["id"])
                    self.assertGreater(item.get("step", 1), 0, item["id"])

    def test_package_list_uses_current_plasma_package_names(self):
        packages = (ROOT / "config/package-lists/metricos.list.chroot").read_text().splitlines()
        packages = {line.strip() for line in packages if line.strip() and not line.lstrip().startswith("#")}
        self.assertIn("plasma-workspace", packages)
        self.assertIn("kwin-wayland", packages)
        self.assertNotIn("plasma-workspace-wayland", packages)
        self.assertNotIn("gamescope", packages)
        self.assertIn("firefox-esr", packages)
        self.assertIn("python3-pyqt6", packages)

    def test_chrome_hook_pins_google_primary_fingerprint(self):
        hook = (ROOT / "config/hooks/normal/0900-google-chrome.hook.chroot").read_text()
        self.assertIn("https://dl.google.com/linux/linux_signing_key.pub", hook)
        self.assertRegex(hook, r"EB4C1BFD4F042F6DDDCCEC917721F63BD38B4796")
        self.assertIn("apt-secure true", (ROOT / "build-iso.sh").read_text())

    def test_build_script_installs_toolchain_before_checking_it(self):
        script = (ROOT / "build-iso.sh").read_text()
        install = script.index("apt-get install -y live-build")
        check = script.index('command -v "$x"', install)
        self.assertLess(install, check)
        self.assertIn('WORK_DIR must be a child of the project directory', script)
        self.assertIn('OUTPUT_DIR must be a child of the project directory', script)

    def test_build_script_checks_disk_space_before_apt(self):
        script = (ROOT / "build-iso.sh").read_text()
        disk_check = script.index('FREE_KB="$(df -Pk "$SCRIPT_DIR"')
        apt_update = script.index("apt-get update")
        self.assertLess(disk_check, apt_update)
        self.assertIn("MIN_FREE_GB", script)

    def test_cloud_workflow_is_manual_and_verifies_before_upload(self):
        workflow = (ROOT / ".github/workflows/build-metricos.yml").read_text()
        self.assertIn("workflow_dispatch:", workflow)
        self.assertIn("actions/checkout@v7", workflow)
        self.assertIn("actions/upload-artifact@v7.0.2", workflow)
        self.assertLess(workflow.index("./verify-iso.sh"), workflow.index("actions/upload-artifact@v7.0.2"))
        self.assertIn("WITH_CHROME", workflow)
        self.assertIn("WITH_INSTALLER", workflow)

    def test_windows_cloud_guide_exists(self):
        guide = ROOT / "WINDOWS-CLOUD-BUILD.md"
        self.assertTrue(guide.is_file())
        self.assertIn("no Ubuntu installation required", guide.read_text())

    def test_required_project_files_exist(self):
        for name in ("build-iso.sh", "verify-iso.sh", "README.md", "metricos-spec.json"):
            self.assertTrue((ROOT / name).is_file(), name)


if __name__ == "__main__":
    unittest.main()
